export interface ItemEntrega {
    id: number;
    entrega_id: number;
    produto_id: number;
    quantidade: number;
}