export interface log {
    id: number;
    usuario_id: number;
    acao: string;
    data_hora: Date;
}