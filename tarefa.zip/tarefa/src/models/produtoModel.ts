export interface Produto {
    id: number;
    nome: string;
    descricao: string;
    peso_unitario_kg: number;
}