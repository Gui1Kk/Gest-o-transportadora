export interface Veiculo {
    id: number;
    placa: string;
    modelo: string;
    capacidade_kg: number;
}